import React, { useState } from "react";
import style from "./style.module.css";

const PersonCard = (props) => {
  const [state, setState] = useState({
    clickCount: 0,
  });

  return (
    <div>
      <h1>
        {props.lastName}, {props.firstName}
      </h1>
      <p>Age: {props.age}</p>
      <p>Hair Color: {props.hairColor}</p>
      <button className={style.btn}>Increase {props.firstName}'s Age</button>
    </div>
  );
};

export default PersonCard;
